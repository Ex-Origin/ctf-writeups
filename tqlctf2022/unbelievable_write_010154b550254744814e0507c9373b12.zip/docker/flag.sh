#!/bin/bash
echo $1 > /home/ctf/flag
chmod 740 /home/ctf/flag