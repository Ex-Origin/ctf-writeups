#ifndef	_PATHS_H_
#define _PATHS_H_

#define _PATH_DEV	"/dev/"

#endif /* _PATHS_H_ */
