int isatty(int id) {
  return 0;
}
