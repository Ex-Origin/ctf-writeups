import os
import subprocess

def banner():
    print("Pleas input your PHP code, and we will execute it! ")
    print("You should end with a single line \"QUIT\". ")
    print("")
    print("=================== Example ======================")
    print("+ <?php                                          +")
    print("+ echo \"Hello, world!\"                           +")
    print("+ ?>                                             +")
    print("+ QUIT                                           +")
    print("==================================================")
    print("")

def read_exp():
    banner()
    content, recv = "", ""
    recv = input()
    while recv.startswith("QUIT") is False:
        content += recv
        if recv != "\n":
            content += "\n"
        recv = input()
    return content


def main():
    exp_content = read_exp()

    with open("/tmp/exp.php", "w") as f:
        f.write(exp_content)
        f.close()

    p = subprocess.Popen("php /tmp/exp.php", stdout=subprocess.PIPE, shell=True)
    p.wait()
    out = p.stdout.readlines()
    out = b''.join(out)
    print(out.decode("UTF-8"))
    

if __name__ == "__main__":
    main()